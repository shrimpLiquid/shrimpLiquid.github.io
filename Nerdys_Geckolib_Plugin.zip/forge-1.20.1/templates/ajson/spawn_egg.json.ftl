{
    "parent": "item/template_spawn_egg"
}